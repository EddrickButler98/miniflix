window.onload = function() {
    var user_profiles = '{ "usernames" : [' +
            '{ "userName": "EddrickButler98", "cityState" : "Sardis, Mississippi", "zipCode" : 38666, "custID" : "672020", "Deposit" : "$23,024.76", "withDrawal" : "($3,482.88)", "CurrentBalance" : "$19,541.88" },' +
            '{ "userName": "JackBlack9182", "cityState" : "Memphis, Tennessee", "zipCode" : "37501", "custID" : "515366", "Deposit" : "$28,853.26", "withDrawal" : "($12,332.38)", "CurrentBalance" : "$16,520.88"  },' +
            '{ "userName": "PeterLowndes2938", "cityState" : "Chicago, Illinois", "zipCode" : "60007", "custID" : "203777", "Deposit" : "$3,997.49", "withDrawal" : "($12,085.25)", "CurrentBalance" : "($8,087.76)"  },' +
            '{ "userName": "LisaReenes1234", "cityState" : "Dallas, Texas", "zipCode" : "75001", "custID" : "473252", "Deposit" : "$10,128.04", "withDrawal" : "($6,417.37)", "CurrentBalance" : "$3,710.67"  },' +
            '{ "userName": "Calown1955", "cityState" : "Atlanta, Georgia", "zipCode" : "30301", "custID" : "429252", "Deposit" : "$28,632.58", "withDrawal" : "($8,224.71)", "CurrentBalance" : "$20,407.87"  },' + 
            '{ "userName": "CrazyJoe123", "cityState" : "Destin, Florida", "zipCode" : "92742", "custID" : "716391", "Deposit" : "$16,856.69", "withDrawal" : "($18,367.26)", "CurrentBalance" : "($1,510.56)"  },' +
            '{ "userName": "CrazyJoe123", "cityState" : "Destin, Florida", "zipCode" : "92742", "custID" : "716391", "Deposit" : "$17,722.91", "withDrawal" : "($870.81)", "CurrentBalance" : "$16,852.10"  },' +
            '{ "userName": "CrazyJoe123", "cityState" : "Destin, Florida", "zipCode" : "92742", "custID" : "716391", "Deposit" : "$18,952.61", "withDrawal" : "($18,980.19)", "CurrentBalance" : "($27.58)"  },' +
            '{ "userName": "CrazyJoe123", "cityState" : "Destin, Florida", "zipCode" : "92742", "custID" : "716391", "Deposit" : "$26,338.23", "withDrawal" : "($19,424.71)", "CurrentBalance" : "$6,913.52"  },' +
            '{ "userName": "CrazyJoe123", "cityState" : "Destin, Florida", "zipCode" : "92742", "custID" : "716391", "Deposit" : "$14,227.06", "withDrawal" : "($9,634.75)", "CurrentBalance" : "$4,592.31"  } ]}';

        var obj = JSON.parse(user_profiles);
        document.getElementById("username").innerHTML = obj.usernames[0].userName;
        document.getElementById("citystate").innerHTML = obj.usernames[0].cityState;
        document.getElementById("zipcode").innerHTML = obj.usernames[0].zipCode;
        document.getElementById("custID1").innerHTML = obj.usernames[0].custID;
        document.getElementById("deposits").innerHTML = obj.usernames[0].Deposit;
        document.getElementById("withdraw").innerHTML = obj.usernames[0].withDrawal;
        document.getElementById("currentbal").innerHTML = obj.usernames[0].CurrentBalance;

        document.getElementById("username2").innerHTML = obj.usernames[1].userName;
        document.getElementById("citystate2").innerHTML = obj.usernames[1].cityState;
        document.getElementById("zipcode2").innerHTML = obj.usernames[1].zipCode;
        document.getElementById("custID2").innerHTML = obj.usernames[1].custID;
        document.getElementById("deposits2").innerHTML = obj.usernames[1].Deposit;
        document.getElementById("withdraw2").innerHTML = obj.usernames[1].withDrawal;
        document.getElementById("currentbal2").innerHTML = obj.usernames[1].CurrentBalance;

        document.getElementById("username3").innerHTML = obj.usernames[2].userName;
        document.getElementById("citystate3").innerHTML = obj.usernames[2].cityState;
        document.getElementById("zipcode3").innerHTML = obj.usernames[2].zipCode;
        document.getElementById("custID3").innerHTML = obj.usernames[2].custID;
        document.getElementById("deposits3").innerHTML = obj.usernames[2].Deposit;
        document.getElementById("withdraw3").innerHTML = obj.usernames[2].withDrawal;
        document.getElementById("currentbal3").innerHTML = obj.usernames[2].CurrentBalance;

        document.getElementById("username4").innerHTML = obj.usernames[3].userName;
        document.getElementById("citystate4").innerHTML = obj.usernames[3].cityState;
        document.getElementById("zipcode4").innerHTML = obj.usernames[3].zipCode;
        document.getElementById("custID4").innerHTML = obj.usernames[3].custID;
        document.getElementById("deposits4").innerHTML = obj.usernames[3].Deposit;
        document.getElementById("withdraw4").innerHTML = obj.usernames[3].withDrawal;
        document.getElementById("currentbal4").innerHTML = obj.usernames[0].CurrentBalance;

        document.getElementById("username5").innerHTML = obj.usernames[4].userName;
        document.getElementById("citystate5").innerHTML = obj.usernames[4].cityState;
        document.getElementById("zipcode5").innerHTML = obj.usernames[4].zipCode;
        document.getElementById("custID5").innerHTML = obj.usernames[4].custID;
        document.getElementById("deposits5").innerHTML = obj.usernames[4].Deposit;
        document.getElementById("withdraw5").innerHTML = obj.usernames[4].withDrawal;
        document.getElementById("currentbal5").innerHTML = obj.usernames[4].CurrentBalance;

        document.getElementById("username6").innerHTML = obj.usernames[5].userName;
        document.getElementById("citystate6").innerHTML = obj.usernames[5].cityState;
        document.getElementById("zipcode6").innerHTML = obj.usernames[5].zipCode;
        document.getElementById("custID6").innerHTML = obj.usernames[5].custID;
        document.getElementById("deposits6").innerHTML = obj.usernames[5].Deposit;
        document.getElementById("withdraw6").innerHTML = obj.usernames[5].withDrawal;
        document.getElementById("currentbal6").innerHTML = obj.usernames[5].CurrentBalance;

        document.getElementById("username7").innerHTML = obj.usernames[6].userName;
        document.getElementById("citystate7").innerHTML = obj.usernames[6].cityState;
        document.getElementById("zipcode7").innerHTML = obj.usernames[6].zipCode;
        document.getElementById("custID7").innerHTML = obj.usernames[6].custID;
        document.getElementById("deposits7").innerHTML = obj.usernames[6].Deposit;
        document.getElementById("withdraw7").innerHTML = obj.usernames[6].withDrawal;
        document.getElementById("currentbal7").innerHTML = obj.usernames[6].CurrentBalance;

        document.getElementById("username8").innerHTML = obj.usernames[7].userName;
        document.getElementById("citystate8").innerHTML = obj.usernames[7].cityState;
        document.getElementById("zipcode8").innerHTML = obj.usernames[7].zipCode;
        document.getElementById("custID8").innerHTML = obj.usernames[7].custID;
        document.getElementById("deposits8").innerHTML = obj.usernames[7].Deposit;
        document.getElementById("withdraw8").innerHTML = obj.usernames[7].withDrawal;
        document.getElementById("currentbal8").innerHTML = obj.usernames[7].CurrentBalance;

        document.getElementById("username9").innerHTML = obj.usernames[8].userName;
        document.getElementById("citystate9").innerHTML = obj.usernames[8].cityState;
        document.getElementById("zipcode9").innerHTML = obj.usernames[8].zipCode;
        document.getElementById("custID9").innerHTML = obj.usernames[8].custID;
        document.getElementById("deposits9").innerHTML = obj.usernames[8].Deposit;
        document.getElementById("withdraw9").innerHTML = obj.usernames[8].withDrawal;
        document.getElementById("currentbal9").innerHTML = obj.usernames[8].CurrentBalance;
}
